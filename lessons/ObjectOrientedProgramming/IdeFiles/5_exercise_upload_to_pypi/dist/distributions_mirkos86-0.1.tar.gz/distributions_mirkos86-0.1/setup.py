from setuptools import setup

setup(name='distributions_mirkos86',
      version='0.1',
      description='Binomial and Gaussian distributions',
      packages=['distributions_mirkos86'],
      author = 'Mirko Serino',
      author_email = 'mirkos.serino@gmail.com',
      url = 'https://test.pypi.org/legacy/',
      zip_safe=False)
